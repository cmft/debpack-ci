#!/usr/bin/env python

import json
import requests


class AptlyApiRequests(object):

    """ AptlyApiRequests
    Instances of this class will be able to talk
    to the Aptly REST API remotely.
    """

    def __init__(self, url, user=None, password=None):
        """
        Pass url and port to the constructor
        to initialize instance.
        """

        self.session = requests.Session()
        self.session.headers = {'content-type': 'application/json'}
        self.session.verify = False

        if password is not None and user is not None:
            self.session.auth = (user, password)

        self.cfg = {
            # Routes
            'route_snap': url + '/api/snapshots/',
            'route_repo': url + '/api/repos/',
            'route_file': url + '/api/files/',
            'route_pack': url + '/api/packages/',
            'route_pub': url + '/api/publish/',
            'route_graph': url + '/api/graph/',
            'route_vers': url + '/api/version/',
        }

    def get_version(self):
        """
        GET /api/version
        Return current aptly version.
        """
        url = self.cfg['route_vers']
        r = self.session.get(url, headers=self.session.headers, verify=False)
        resp = json.loads(r.content)
        return resp


    def file_upload(self, dir_name, file_path):
        """ Upload files to aptly
        curl -X POST -F file=@$FILE --insecure --user $pass
        """
        f = {
            'file': open(file_path, 'rb')
        }

        url = self.cfg['route_file'] + dir_name
        r = requests.post(url, files=f, auth=self.session.auth,
                          verify=self.session.verify)

        resp_data = json.loads(r.content)
        return resp_data


    def repo_add_package_from_upload(self, repo_name, dir_name, file_name=None,
                                     params=None):
        """ Add package from upload
        curl -v -X PUT -H 'Content-Type: application/json' --data '{}' \
        https://debrepos.cells.es/api/publish/:./stretch
        """
        if file_name is None:
            url = self.cfg['route_repo'] + repo_name + '/file/' + dir_name
        else:
            url = self.cfg['route_repo'] + repo_name + \
                '/file/' + dir_name + '/' + file_name

        if params is not None:
            query_param = {
                'noRemove': params.no_remove,
                'forceReplace': params.force_replace
            }
        else:
            query_param = {
                'noRemove': 0,
                'forceReplace': 1
            }

        r = self.session.post(url, params=query_param)
        resp_data = json.loads(r.content)

        return resp_data

    def move_package(self, packages, orig_repo="alba-deb9-staging",
                        dest_repo="alba-deb9-production"):
        """Move packages from the orig. repository to the dest. repository
        :param packages: list of packages (search_package output)
        :param orig_repo: orig. repository
        :param dest_repo: destination repository
        """
        # add packages by key in dest repo
        self.copy_packages(packages, dest_repo)
        # delete packages by key in orig_repo
        self.delete_packages(packages, orig_repo)

    def copy_packages(self, packages, dest_repo, force_overwrite=True):
        """Method to copy package from one repo to another
        :param packages: package query output
        :param dest_repo: destination repository
        :param force_overwrite: overwrite if existing
        :return: cmd output
        """
        url = self.cfg['route_repo'] + dest_repo + "/packages"
        data = {
            'PackageRefs': packages,
            'ForceOverwrite': force_overwrite
        }

        r = self.session.post(url, headers=self.session.headers,
                              verify=False, data=json.dumps(data))
        resp = json.loads(r.content)
        return resp

    def search_package(self, query, repo_name):
        """Method to get all the packages that match with the query
        :param query: package query; https://www.aptly.info/doc/feature/query/
        :param repo_name: repository
        :return: package list
        """
        url = self.cfg['route_repo'] + repo_name + "/packages?q=" + query
        r = self.session.get(url, headers=self.session.headers, verify=False)
        resp = json.loads(r.content)
        return resp

    def delete_packages(self, packages, repo_name):
        """
        Method for deleting packages from a repository
         :param packages: List of string with the package description
         e.g. ["Pall apackage 0.1.0 ebcaf7a13cb11e2e"]}
        :param repo_name: Repository name
        """
        url = self.cfg['route_repo'] + repo_name + "/packages"
        data = {
            'PackageRefs': packages
        }

        r = self.session.delete(url, headers=self.session.headers,
                                verify=False, data=json.dumps(data))
        resp = json.loads(r.content)
        return resp

    def publish_switch(self, passphrase=None, prefix="", dist="stretch",
                       gpgkey="AEF59AB58141409E", force_overwrite=True):
        """
        UPDATE PUBLISHED LOCAL REPO/SWITCH PUBLISHED
        PUT /api/publish/:prefix/:distribution
        API action depends on published repository contents:
        if local repository has been published, published repository would be
        updated to match local repository contents
        if snapshots have been been published, it is possible to switch each
        component to new snapshot

        """
        url = self.cfg['route_pub'] + prefix + ':/' + dist

        data = {
            'ForceOverwrite': force_overwrite
        }

        if passphrase is not None:
            data['GpgKey'] = gpgkey
            data['Passphrase'] = passphrase

        r = self.session.put(url, data=json.dumps(data))
        resp = json.loads(r.content)
        return resp



if __name__ == "__main__":
    url="https://debrepos.cells.es"
    user = "aptly"
    password = raw_input()
    # passphrase = raw_input()
    api = AptlyApiRequests(url, user, password)
    print api.get_version()
    ## Upload files
    print api.file_upload("alba-deb9-staging",
                          "/tmp/packages/python-dummy_1.2.5a0-1_all.deb")
    ## repo_add_package_from_upload
    print api.repo_add_package_from_upload("alba-deb9-staging",
                                           "alba-deb9-staging")
    ## Publish update dist (passphrase does not work with GPG2)
    print api.publish_switch(passphrase)