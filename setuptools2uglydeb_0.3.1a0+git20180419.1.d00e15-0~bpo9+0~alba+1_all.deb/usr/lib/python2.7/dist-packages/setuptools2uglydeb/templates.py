#!/usr/bin/env python


__all__ = ["override_dh_fixperms", "github_watch", "gitcells_watch",
           "postinstall", "prerm", "override_dh_install",
           "override_dh_auto_test", "override_dh_python2"]

override_dh_fixperms = """
override_dh_fixperms:
\tchmod 0644 debian/{pkg_name}/usr/{install_path}/{module_name}-*.egg-info/dependency_links.txt
\tchmod 0644 debian/{pkg_name}/usr/{install_path}/{module_name}-*.egg-info/PKG-INFO
\tchmod 0644 debian/{pkg_name}/usr/{install_path}/{module_name}-*.egg-info/top_level.txt
\tdh_fixperms
"""

override_dh_install = """
override_dh_install:
\tdh_install
\t# remove the launchers
\trm -rf debian/{pkg_name}/usr/bin/
"""

override_dh_python2 = """
override_dh_python2:
\t# use a venv-friendly shebang (avoid auto-rsubstitution by dh_python2)
\tdh_python2 --shebang='/usr/bin/env python'
"""

override_dh_auto_test = """
override_dh_auto_test:
\techo 'Skipping tests'
"""

github_watch = """version=4
opts=filenamemangle=s/.+\/v?(\d\S+)\.tar\.gz/{project}-$1\.tar\.gz/ \\
    https://github.com/{project}/tags .*/v?(\d\S+)\.tar\.gz
"""

gitcells_watch = """version=4
opts=filenamemangle=s/.*\/(\d\S+)\/archive\.tar\.gz/{project_name}-$1\.tar\.gz/g \
  https://git.cells.es/{project}/tags?sort=updated_desc .*/(\d\S+)/archive\.tar\.gz
"""

postinstall = """#!/bin/sh -e
python -m compileall /usr/share/{pkg_name}/{module_name}

#DEBHELPER#
exit 0

"""

prerm = """#!/bin/sh -e

if [ "$1" = "remove" ]; then
	find /usr/share/{pkg_name} -iname "*.pyc"  -exec rm {{}} \;
fi

#DEBHELPER#
exit 0

"""