#!/usr/bin/env python

import os
import git
import sys
import mock
import stdeb
import pysvn
import argparse
import setuptools
import subprocess
from time import gmtime, strftime, sleep

from aptly import AptlyApiRequests
from templates import (override_dh_fixperms,
                       github_watch,
                       gitcells_watch,
                       postinstall,
                       prerm,
                       override_dh_install,
                       override_dh_auto_test,
                       override_dh_python2)

DEBIAN_9 = {
    "version": "0~bpo9+0~alba+1",
    "suite": "stretch-backports"
}


class SetupTools2UglyDeb(object):

    REST_API_URL = "https://debrepo.cells.es"

    def __init__(self):
        self.pkg_info = None
        self.pkg_name = None
        self.deb_ver = None
        self.deb_pkg_name = None
        self._upstream_ver = None
        self.source_path = None
        self._path = os.path.dirname(os.path.abspath(__file__))

    def get_setup_args(self, path):
        os.chdir(path)
        sys.path.append(path)
        with mock.patch.object(setuptools, 'setup') as mock_setup:
            import setup  # This is setup.py which calls setuptools.setup
            _, kwargs = mock_setup.call_args
            return kwargs

    def _createCopyright(self):
        pass


    def uploadPackage(self, user_passwd, passphrase=None, changes_file=None,
                      repo_id="deb9_ugly"):
        user, password = user_passwd.split(":")
        api = AptlyApiRequests(self.REST_API_URL, user, password)

        repos = {"deb9_staging": "alba-deb9-staging",
                 "deb9_production": "alba-deb9-production",
                 "deb9_ugly": "alba-deb9-ugly",
                 }

        if changes_file is None:
            deb_pkg_name = "{0}_{1}-{2}".format(self.pkg_name,
                                                self._upstream_ver,
                                                self.deb_ver)
            changes_file = "{0}/deb_dist/" \
                           "{1}_amd64.changes".format(self.source_path,
                                                      deb_pkg_name)

            root_path = "{0}/deb_dist".format(self.source_path)
            os.chdir(root_path)

        else:
            root_path = os.path.dirname(changes_file)


        # Read changes file
        with open(changes_file) as f:
            content = f.readlines()

        # Get the files
        i = -1
        files_2_upload = []
        while not "Files:" in content[i]:
            pkg_file = content[i].split()[-1]

            if ".buildinfo" not in pkg_file:
                files_2_upload.append(pkg_file)
            i -= 1

        # upload the files
        for file_2_upload in files_2_upload:
            file_fullpath = os.path.abspath(
                os.path.join(root_path, file_2_upload))
            print api.file_upload(repos.get(repo_id), file_fullpath)

        # repo_add_package_from_upload
        for filename in files_2_upload:
            if filename.rsplit('.',1)[1] in ["deb", "dsc"]:
                print api.repo_add_package_from_upload(repos.get(repo_id),
                                                       repos.get(repo_id),
                                                       filename)

        # publish the repo
        print api.publish_switch(passphrase=passphrase)

    def movePackage(self, user_passwd, passphrase=None, changes_file=None,
                    orig_repo_id="deb9_staging",
                    dest_repo_id="deb9_production"):

        user, password = user_passwd.split(":")
        api = AptlyApiRequests(self.REST_API_URL, user, password)

        repos = {"deb9_staging": "alba-deb9-staging",
                 "deb9_production": "alba-deb9-production",
                 "deb9_ugly": "alba-deb9-ugly",
                 }

        orig_repo = repos[orig_repo_id]
        dest_repo = repos[dest_repo_id]

        if changes_file is None:
            deb_pkg_name = "{0}_{1}-{2}".format(self.pkg_name,
                                                self._upstream_ver,
                                                self.deb_ver)
            changes_file = "{0}/deb_dist/" \
                           "{1}_amd64.changes".format(self.source_path,
                                                      deb_pkg_name)

        # Read changes file
        with open(changes_file) as f:
            content = f.readlines()

        source = content[2].split()[1]
        # binaries = content[3].split()[1:]
        version = content[5].split()[1]

        # Get all package that match with the sources name
        packages = []
        query = "Source ({0})".format(source)
        packages += api.search_package(query, orig_repo)
        query = "Name ({0})".format(source)
        packages += api.search_package(query, orig_repo)

        candidates_pkgs = []
        for package in packages:
            if version in package:
                candidates_pkgs.append(package)

        # Move packages that match with the version
        api.move_package(candidates_pkgs, orig_repo, dest_repo)

        # publish the repositories
        print api.publish_switch(passphrase=passphrase)


    def _debianizePkgName(self):
        pkg_name = self.pkg_info["name"].replace("_", "-")
        return pkg_name.lower()

    def _getGitHash(self):
        repo = git.Repo(self.source_path)
        hc = repo.head.commit
        return str(hc)[:6]

    def _getSVNRev(self):
        info = pysvn.Client().info(self.source_path)
        rev = info.get('revision')
        return rev.number

    def createDebSource(self, path, os_info=DEBIAN_9, keys=None):
        if keys is None:
            keys = ""
        self.source_path = path
        self.pkg_info = self.get_setup_args(path=self.source_path)
        self.pkg_info["packager"] = os.environ['HOST_USER']
        self.pkg_name = self._debianizePkgName()
        self.deb_ver = os_info["version"]
        # Add the package OS information
        stdeb_ops = "--debian-version {version} " \
                    "--suite {suite}".format(**os_info)
        # Add the setup information
        # Package name
        self.deb_pkg_name = self._debianizePkgName()
        keywords = self.pkg_info.get("keywords", keys)
        if keywords and "DS" in keywords.split():
            self.deb_pkg_name = "tangods-{0}".format(self.deb_pkg_name)
        elif keywords and "APP" in keywords.split() \
                or "GUI" in keywords.split():
            pass
        else:
            self.deb_pkg_name = "python-{0}".format(self.deb_pkg_name)
        stdeb_ops += " --package {0}".format(self.deb_pkg_name)

        # Fix version
        if self.pkg_info.get("version").find("alpha") > -1:
            try:
                # Get Git version
                version = "+git{0}.{1}.{2}".format(strftime("%Y%m%d",
                                                            gmtime()),
                                                   1, self._getGitHash())
            except:
                # Get SVN version
                version = "+svn~r{0}".format(self._getSVNRev)

            stdeb_ops += " --upstream-version-suffix {0}".format(version)
            self._upstream_ver = self.pkg_info.get("version").replace("-alpha",
                                                                      "a0") +\
                                 version
        else:
            self._upstream_ver = self.pkg_info.get("version")
        # Add copyright
        if self.pkg_info.get('license', None) == 'LGPL':
            copyright_type = "copyright-LGPL-3+"
        else:
            copyright_type = "copyright-GPL-3+"
        copyright_path = os.path.join(self._path, "res", copyright_type)
        with open(copyright_path, 'r') as f:
            read_data = f.read()
            if self.pkg_info.get("maintainer", None) is None:
                self.pkg_info["maintainer"] = "Unknown"
            if self.pkg_info.get("maintainer_email", None) is None:
                self.pkg_info["maintainer_email"] = "controls-software@cells.es"
            if self.pkg_info.get("url", None) is None:
                self.pkg_info["url"] = self._getRepoURL()
            copyright = read_data.format(**self.pkg_info)
        f.close()

        with open('/tmp/copyright', 'w') as f:
            f.write(copyright)
        f.close()
        stdeb_ops += " --copyright-file /tmp/copyright"
        # Run stdeb sdist_dsc cmd
        stdeb_cmd = "setup.py --command-packages=stdeb.command " \
                    "sdist_dsc {0}".format(stdeb_ops)
        p = subprocess.call('python {0}'.format(stdeb_cmd), shell=True)

    def _build_package(self):
        pkg_name = "{0}-{1}".format(self.pkg_name, self._upstream_ver)
        path = "{0}/deb_dist/{1}".format(self.source_path, pkg_name)
        os.chdir(path)
        p = subprocess.call('debuild -us -uc', shell=True)

    def _createDebRepo(self, install_path="/packaging"):
        # get project name
        try:
            project_name = self._getProjectName()
        except:
            project_name = self.pkg_name
        path = "{0}/deb_dist".format(self.source_path)
        os.chdir(path)
        repo_path = "{0}/{1}_deb".format(install_path, project_name)
        cmd = "gbp import-dsc *{0}*.dsc " \
              "{1} --pristine-tar".format(self._upstream_ver, repo_path)
        p = subprocess.call(cmd, shell=True)
        # Add remote repository
        g = git.cmd.Git(repo_path)
        repo = "https://git.cells.es/ctpkg/{0}_deb.git".format(project_name)
        g.execute(["git", "remote", "add", "origin", repo])
        return repo_path

    def createRemoteRepo(self, project_name=None, tags="TODO"):
        # get project name
        if project_name is None:
            try:
                project_name = self._getProjectName()
            except:
                project_name = self.pkg_name

        descript = "Repo for packaging {0} on debian".format(project_name)

        cmd = ". /etc/custom_bashrc; create_ctpkg_project " \
              "{0}_deb \"{1}\" \"{2}\" > /dev/null 2>&1"
        subprocess.Popen(['bash', '-c',
                          cmd.format(project_name, descript, tags)])

    def _getProjectName(self):
        g = git.cmd.Git(self.source_path)
        remote = g.execute(["git", "config", "--get", "remote.origin.url"])
        return remote.rsplit("/", 1)[1].split('.')[0]

    def fixStandarVersion(self, repo_path):
        os.chdir(os.path.join(repo_path, "debian"))

        with open('control', 'r+') as f:
            content = f.read()
            f.seek(0)
            f.truncate()
            f.write(content.replace('Standards-Version: 3.9.6',
                                    'Standards-Version: 3.9.8'))
        f.close()
        # Commit changes
        self.commitChanges(repo_path, ["debian/control"],
                           "Fix standards version")

    def addBuildDepedencies(self, repo_path, dependencies):
        os.chdir(os.path.join(repo_path, "debian"))
        ori_depends = "Build-Depends: dh-python, python-setuptools " \
                      "(>= 0.6b3), python-all (>= 2.6.6-3), debhelper (>= 9)"
        depends = ori_depends
        for dep in dependencies:
            depends += ", {0}".format(dep)

        with open('control', 'r+') as f:
            content = f.read()
            f.seek(0)
            f.truncate()
            f.write(content.replace(
                ori_depends,
                depends))
        f.close()
        # Commit changes
        self.commitChanges(repo_path, ["debian/control"],
                           "Add build dependencies")

    def addInstallDepedencies(self, repo_path, dependencies):
        os.chdir(os.path.join(repo_path, "debian"))
        depends = "Depends: ${misc:Depends}, ${python:Depends}"
        for dep in dependencies:
            depends += ", {0}".format(dep)

        with open('control', 'r+') as f:
            content = f.read()
            f.seek(0)
            f.truncate()
            f.write(content.replace(
                'Depends: ${misc:Depends}, ${python:Depends}',
                depends))
        f.close()
        # Commit changes
        self.commitChanges(repo_path, ["debian/control"],
                           "Add install dependencies")

    def addFixPermsOverride(self, repo_path, install_path):
        os.chdir(os.path.join(repo_path, "debian"))

        module_name = self.pkg_info["name"]
        override = override_dh_fixperms.format(install_path=install_path,
                                               pkg_name=self.deb_pkg_name,
                                               module_name=module_name)
        with open('rules', 'a') as f:
            f.write(override)
        f.close()
        # Commit changes
        self.commitChanges(repo_path, ["debian/rules"],
                           "Add dh_fixperms override")

    def addSkipTestOverride(self, repo_path):
        os.chdir(os.path.join(repo_path, "debian"))

        with open('rules', 'a') as f:
            f.write(override_dh_auto_test)
        f.close()
        # Commit changes
        self.commitChanges(repo_path, ["debian/rules"],
                           "Add dh_auto_test override")

    def addPython2Override(self, repo_path):
        os.chdir(os.path.join(repo_path, "debian"))

        with open('rules', 'a') as f:
            f.write(override_dh_python2)
        f.close()
        # Commit changes
        self.commitChanges(repo_path, ["debian/rules"],
                           "Add dh_python2 override")

    def addManPagesLintianOverride(self, repo_path):
        os.chdir(os.path.join(repo_path, "debian"))
        file = "{0}.lintian-overrides".format(self.deb_pkg_name)
        with open(file, 'a') as f:
            f.write("# Man pages will be not generated\n")
            f.write("binary-without-manpage\n")
        f.close()
        # Commit changes
        self.commitChanges(repo_path, ["debian/{0}".format(file)],
                           "Add dh_fixperms override")

    def _getRepoURL(self):
        try:
            # Get git remote url without .git
            g = git.cmd.Git(self.source_path)
            url = g.execute(["git", "config", "--get", "remote.origin.url"])
            # Remove .git
            if url.endswith('.git'):
                url = url[:-4]
        except:
            try:
                # Get svn url
                info = pysvn.Client().info(self.source_path)
                url = info.get('url')
            except:
                url = "Unknown"
        return url

    def fixWatchFile(self, repo_path):
        os.chdir(os.path.join(repo_path, "debian"))
        url = self._getRepoURL()

        update = False
        if "git.cells.es" in url:
            project = url.split("git.cells.es/")[1]
            project_name = project.split('/')[1]
            watch = gitcells_watch.format(project=project,
                                          project_name=project_name)
            update = True
        elif "github.com" in url:
            project = url.split("github.com/")[1]
            watch = github_watch.format(project=project)
            update = True

        if update:
            with open("watch", 'w') as f:
                f.write(watch)
            f.close()
            # Commit changes
            self.commitChanges(repo_path, ["debian/watch"],
                               "Point watch file to git repository")

    def addPrePostScript(self, repo_path):
        os.chdir(os.path.join(repo_path, "debian"))
        post = "{0}.postinstall".format(self.deb_pkg_name)
        module_name = self.pkg_info["name"]
        with open(post, 'w+') as f:
            f.write(postinstall.format(pkg_name=self.deb_pkg_name,
                                       module_name=module_name))
        f.close()
        pre = "{0}.prerm".format(self.deb_pkg_name)
        with open(pre, 'w+') as f:
            f.write(prerm.format(pkg_name=self.deb_pkg_name))
        f.close()
        # Commit changes
        files = ["debian/{0}".format(post),
                 "debian/{0}".format(pre)
                 ]
        self.commitChanges(repo_path, files, "Add pre/post scripts")

    def commitChanges(self, repo_path, files, msg):
        repo = git.Repo(repo_path)
        index = repo.index
        index.add(files)
        index.commit(msg)

    def removeLaunchers(self, repo_path):
        os.chdir(os.path.join(repo_path, "debian"))
        with open("rules", 'a') as f:
            f.write(override_dh_install.format(
                pkg_name=self.deb_pkg_name))
        f.close()
        # Commit changes
        self.commitChanges(repo_path, ["debian/rules"],
                           "Remove /usr/bin folder")

    def changeInstallationPath(self, repo_path, path="/usr/share"):
        build_name = "export PYBUILD_NAME={pkg_name}".format(
            pkg_name=self.pkg_name)

        install_args = "export PYBUILD_INSTALL_ARGS=" \
                       "--install-lib={path}/{pkg_name} " \
                       "--no-compile".format(path=path,
                                             pkg_name=self.deb_pkg_name)
        with open('rules', 'r+') as f:
                content = f.read()
                f.seek(0)
                f.truncate()
                f.write(content.replace(build_name, install_args))
        f.close()
        # Commit changes
        self.commitChanges(repo_path, ["debian/rules"],
                           "Change installation path")

    def _getLaunchersName(self):
        launchers = []
        scripts = []
        entry_points = self.pkg_info.get('entry_points', {})
        setup_scripts = self.pkg_info.get('scripts', [])
        if len(entry_points) > 0:
            scripts.extend(entry_points.get("console_scripts", []))
            scripts.extend(entry_points.get("gui_scripts", []))

        if len(setup_scripts) > 0:

            scripts.extend(setup_scripts)

        for script in scripts:
            if script.find("=") != -1:
                launcher = script[:script.find("=")].strip()
            else:
                launcher = script
            launchers.append(launcher)
        return launchers

    def relocateLaunchers(self, repo_path, relocation_path="usr/bin"):
        os.chdir(os.path.join(repo_path, "debian"))

        install_file = "{0}.install".format(self.deb_pkg_name)
        link_file = "{0}.links".format(self.deb_pkg_name)

        with open(install_file, 'a') as install_f:
            install_f.write("#!/usr/bin/dh-exec\n")
        install_f.close()

        install_str = "debian/{pkg_name}/usr/bin/{launcher} => " \
                      "/usr/share/{pkg_name}/{launcher}_\n"

        link_str = "usr/share/{pkg_name}/{launcher}_ " \
                   "{relocation_path}/{launcher}\n"

        for launcher in self._getLaunchersName():
            with open(install_file, 'a') as install_f:
                install_f.write(install_str.format(pkg_name=self.deb_pkg_name,
                                                   launcher=launcher))

            with open(link_file, 'a') as link_f:
                link_f.write(link_str.format(pkg_name=self.deb_pkg_name,
                                             launcher=launcher,
                                             relocation_path=relocation_path))
            install_f.close()
            link_f.close()

        path = os.path.join(repo_path, "debian", install_file)
        p = subprocess.call("chmod 777 {0}".format(path), shell=True)
        files = ["debian/{0}".format(install_file),
                 "debian/{0}".format(link_file)]
        self.commitChanges(repo_path, files,
                           "Relocate Launchers")

    def createUglyDeb(self, path, user, os_info=DEBIAN_9):
        print("Creating deb source package...")
        self.createDebSource(path, os_info)
        print("Creating deb package...")
        self._build_package()
        print("Uploading package...")
        self.uploadPackage(user)

    def createLibTemplate(self, path, build_deps=[], install_deps=[], tags="Lib",
                      os_info=DEBIAN_9):
        print("Creating deb source package...")
        self.createDebSource(path, os_info)
        print("Creating deb Repo...")
        repo_path = self._createDebRepo()
        print("Creating ctpkg repository")
        self.createRemoteRepo(tags=tags)
        print("Fixing standard version")
        self.fixStandarVersion(repo_path)
        if len(build_deps) > 0:
            print("Adding build dependencies")
            self.addBuildDepedencies(repo_path, build_deps)
        if len(install_deps) > 0:
            print("Adding install dependencies")
            self.addInstallDepedencies(repo_path, install_deps)
        print("Fixing egg permissions")
        self.addFixPermsOverride(repo_path, "lib/python2.7/dist-packages")

        if len(self._getLaunchersName()) > 0:
            print("Adding lintian overide")
            self.addManPagesLintianOverride(repo_path)
        print("Updating watch file")
        self.fixWatchFile(repo_path)

    def createDsTemplate(self, path, build_deps=[], install_deps=[], tags="Ds",
                     os_info=DEBIAN_9):
        # Add default dependencies
        if "dh-exec" not in build_deps:
            build_deps.append("dh-exec")
        if "python-tango" not in install_deps:
            install_deps.append("python-tango")
        print("Creating deb source package...")
        self.createDebSource(path, os_info, keys="DS")
        print("Creating deb Repo...")
        repo_path = self._createDebRepo()
        print("Creating ctpkg repository")
        self.createRemoteRepo(tags=tags)
        print("Fixing standard version")
        self.fixStandarVersion(repo_path)
        print("Adding build dependencies")
        self.addBuildDepedencies(repo_path, build_deps)
        print("Adding install dependencies")
        self.addInstallDepedencies(repo_path, install_deps)
        print("Changing installation path")
        self.changeInstallationPath(repo_path)
        print("Relocate launchers")
        self.relocateLaunchers(repo_path, "usr/lib/tango")
        print("Fixing egg permissions")
        self.addFixPermsOverride(repo_path,
                                 "share/{0}".format(self.deb_pkg_name))
        print("Adding skip tests override")
        self.addSkipTestOverride(repo_path)
        print("Remove usr/bin launchers")
        self.removeLaunchers(repo_path)
        print("Adding pre/post scripts")
        self.addPrePostScript(repo_path)
        print("Updating watch file")
        self.fixWatchFile(repo_path)

    def createGuiTemplate(self, path, build_deps=[], install_deps=[],
                      tags="APP, GUI",
                      os_info=DEBIAN_9):
        # Add default dependencies
        if "dh-exec" not in build_deps:
            build_deps.append("dh-exec")
        print("Creating deb source package...")
        self.createDebSource(path, os_info, keys="GUI")
        print("Creating deb Repo...")
        repo_path = self._createDebRepo()
        print("Creating ctpkg repository")
        self.createRemoteRepo(tags=tags)
        print("Fixing standard version")
        self.fixStandarVersion(repo_path)
        print("Adding build dependencies")
        self.addBuildDepedencies(repo_path, build_deps)
        if len(install_deps) > 0:
            print("Adding install dependencies")
            self.addInstallDepedencies(repo_path, install_deps)
        print("Changing installation path")
        self.changeInstallationPath(repo_path)
        print("Relocate launchers")
        self.relocateLaunchers(repo_path)
        print("Fixing egg permissions")
        self.addFixPermsOverride(repo_path,
                                 "share/{0}".format(self.deb_pkg_name))
        # TODO add desktop files
        print("Adding skip tests override")
        self.addSkipTestOverride(repo_path)
        print("Adding dh_python2 install override")
        self.addPython2Override(repo_path)
        print("Adding pre/post scripts")
        self.addPrePostScript(repo_path)
        print("Adding lintian overide")
        self.addManPagesLintianOverride(repo_path)
        print("Updating watch file")
        self.fixWatchFile(repo_path)

###############################################################################
# Entry point methods
###############################################################################
def createUglyDeb():
    parser = argparse.ArgumentParser(description="Create Ugly deb package")
    parser.add_argument('path2module', help='Path to project')
    # parser.add_argument('gpgkey', help='gpg key')
    parser.add_argument('user_passwd', help='user:passwd to access to aptly REST API.')
    args = parser.parse_args()
    path = os.path.abspath(args.path2module)
    api = SetupTools2UglyDeb()
    api.createUglyDeb(path, args.user_passwd)


def createLibTemplate():
    parser = argparse.ArgumentParser(description="Create debian Lib project")
    parser.add_argument('path2module', help='Path to git clone')
    parser.add_argument('-b','--build-deps',
                        help='List of debian build dependencies',
                        nargs='*', default=[])
    parser.add_argument('-i','--install-deps',
                        help='List of debian install dependencies',
                        nargs='*', default=[])
    parser.add_argument('-t', '--tags',
                        help='Comma-separated strings tags (for ctpkg project)',
                        default="Lib", nargs='?')
    args = parser.parse_args()
    path = os.path.abspath(args.path2module)
    build_deps = args.build_deps
    install_deps = args.install_deps
    tags = args.tags
    api = SetupTools2UglyDeb()
    api.createLibTemplate(path, build_deps, install_deps, tags)


def createDsTemplate():
    parser = argparse.ArgumentParser(description="Create debian DS project")
    parser.add_argument('path2module', help='Path to git clone')
    parser.add_argument('-b','--build-deps',
                        help='List of debian build dependencies',
                        nargs='*', default=[])
    parser.add_argument('-i','--install-deps',
                        help='List of debian install dependencies',
                        nargs='*', default=[])
    parser.add_argument('-t', '--tags',
                        help='Comma-separated strings tags (for ctpkg project)',
                        default="DS", nargs='?')
    args = parser.parse_args()
    path = os.path.abspath(args.path2module)
    build_deps = args.build_deps
    install_deps = args.install_deps
    tags = args.tags
    api = SetupTools2UglyDeb()
    api.createDsTemplate(path, build_deps, install_deps, tags)


def createGuiTemplate():
    parser = argparse.ArgumentParser(description="Create debian GUI project")
    parser.add_argument('path2module', help='Path to git clone')
    parser.add_argument('-b','--build-deps',
                        help='List of debian build dependencies',
                        nargs='*', default=[])
    parser.add_argument('-i','--install-deps',
                        help='List of debian install dependencies',
                        nargs='*', default=[])
    parser.add_argument('-t', '--tags',
                        help='Comma-separated strings tags (for ctpkg project)',
                        default="GUI", nargs='?')
    args = parser.parse_args()
    path = os.path.abspath(args.path2module)
    build_deps = args.build_deps
    install_deps = args.install_deps
    tags = args.tags
    api = SetupTools2UglyDeb()
    api.createGuiTemplate(path, build_deps, install_deps, tags)


def upload2aptly():
    parser = argparse.ArgumentParser(description="Upload package to aptly repo")
    parser.add_argument('user_passwd', help='user:passwd to access to aptly REST API.')
    # parser.add_argument('passphrase', help='gpg passphrase')
    parser.add_argument('repository', help='Repository: deb9_production or deb9_staging')
    parser.add_argument('changes_file', help='debian change file')

    args = parser.parse_args()
    api = SetupTools2UglyDeb()
    api.uploadPackage(user_passwd=args.user_passwd,
                      # args.passphrase,
                      changes_file=args.changes_file,
                      repo_id=args.repository)


def movePackage():
    parser = argparse.ArgumentParser(description="Migrate packages from one repo to another")
    parser.add_argument('user_passwd', help='user:passwd to access to aptly REST API.')
    parser.add_argument('orig_repo', help='Orig repository: deb9_production or deb9_staging')
    parser.add_argument('dest_repo', help='Dest. repository: deb9_production or deb9_staging')
    parser.add_argument('changes_file', help='debian change file')

    args = parser.parse_args()
    api = SetupTools2UglyDeb()
    api.movePackage(user_passwd=args.user_passwd,
                    changes_file=args.changes_file,
                    orig_repo_id=args.orig_repo,
                    dest_repo_id=args.dest_repo)


def main():
    upload_to_aptly()

if __name__ == '__main__':
    main()